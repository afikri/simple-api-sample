import React from 'react'
import './App.css'
import { Routes, Route } from 'react-router-dom';
import { Add, Edit, List } from './pages';
import Navbar from './components/Navbar';


const App = () => {
  return (
    <div className='App'>
      <Navbar />
      <Routes>
        <Route path='/' element={<List />} />
        <Route path='/add' element={<Add />} />
        <Route path='/edit/:id' element={<Edit />} />
      </Routes>
    </div>
  )
}

export default App